import os, logging, json
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from dotenv import load_dotenv

# Load .env
load_dotenv()

# Configuration from environment
API_KEY = os.getenv("BINANCE_API_KEY")
API_SECRET = os.getenv("BINANCE_API_SECRET")
USE_TESTNET = os.getenv("USE_TESTNET", "True").lower() == "true"
DRY_RUN = os.getenv("DRY_RUN", "True").lower() == "true"
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "mysecret")

app = FastAPI()

# Lazy import of binance client so the error message is clearer if not installed
try:
    from binance.client import Client
    from binance.exceptions import BinanceAPIException
    from binance.helpers import round_step_size
except Exception as e:
    Client = None
    BinanceAPIException = Exception
    round_step_size = None

logging.basicConfig(level=logging.INFO)

if not API_KEY or not API_SECRET:
    raise ValueError("Please set BINANCE_API_KEY and BINANCE_API_SECRET in .env before running the bot.")


if Client is None:
    raise RuntimeError("python-binance is not installed. Run install.bat to install required packages.")


client = Client(API_KEY, API_SECRET, testnet=USE_TESTNET)


def adjust_quantity(symbol: str, qty: float) -> float:
    """Round qty to symbol's LOT_SIZE stepSize to avoid Binance precision errors."""
    info = client.get_symbol_info(symbol)
    if not info:
        raise ValueError(f"Symbol {symbol} not found")
    lot_filter = next((f for f in info.get("filters", []) if f.get("filterType") == "LOT_SIZE"), None)
    if lot_filter and round_step_size:
        step = float(lot_filter.get("stepSize", "0"))
        if step > 0:
            return float(round_step_size(qty, step))
    return qty


@app.get("/")
def home():
    return {"message": "✅ Trading Bot is running!", "mode": "Testnet" if USE_TESTNET else "Live", "dry_run": DRY_RUN}


@app.get("/balance")
def get_balance():
    try:
        if DRY_RUN:
            return {"balances": [{"asset": "USDT", "free": "10000.00", "locked": "0.00"}]}
        info = client.get_account()
        balances = info.get("balances", [])
        non_zero = [b for b in balances if float(b.get("free", "0")) > 0 or float(b.get("locked", "0")) > 0]
        return {"balances": non_zero}
    except BinanceAPIException as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/buy")
def buy(symbol: str = "BTCUSDT", quantity: float = 0.001):
    try:
        qty = adjust_quantity(symbol, quantity)
        logging.info(f"Placing BUY {symbol} {qty} (dry_run={DRY_RUN})")
        if DRY_RUN or USE_TESTNET:
            client.create_test_order(symbol=symbol, side="BUY", type="MARKET", quantity=qty)
            return {"status": "test_buy_accepted", "symbol": symbol, "qty": qty}
        order = client.order_market_buy(symbol=symbol, quantity=qty)
        return {"status": "buy_placed", "order": order}
    except BinanceAPIException as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/sell")
def sell(symbol: str = "BTCUSDT", quantity: float = 0.001):
    try:
        qty = adjust_quantity(symbol, quantity)
        logging.info(f"Placing SELL {symbol} {qty} (dry_run={DRY_RUN})")
        if DRY_RUN or USE_TESTNET:
            client.create_test_order(symbol=symbol, side="SELL", type="MARKET", quantity=qty)
            return {"status": "test_sell_accepted", "symbol": symbol, "qty": qty}
        order = client.order_market_sell(symbol=symbol, quantity=qty)
        return {"status": "sell_placed", "order": order}
    except BinanceAPIException as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/webhook")
async def webhook(request: Request):
    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    secret = data.get("secret")
    if secret != WEBHOOK_SECRET:
        logging.warning("Webhook called with invalid secret: %s", secret)
        raise HTTPException(status_code=403, detail="Invalid secret")


    action = str(data.get("action", "")).strip().upper()
    symbol = str(data.get("symbol", "BTCUSDT")).upper().replace("BINANCE:", "").replace("/", "")
    try:
        quantity = float(data.get("quantity", 0.0))
    except Exception:
        quantity = 0.0

    if quantity <= 0:
        raise HTTPException(status_code=400, detail="quantity must be > 0")


    logging.info(f"Webhook received action={action} symbol={symbol} qty={quantity}")

    if action == "BUY":
        res = buy(symbol, quantity)
        return {"message": "BUY handled", "result": res}
    elif action == "SELL":
        res = sell(symbol, quantity)
        return {"message": "SELL handled", "result": res}
    else:
        raise HTTPException(status_code=400, detail="Invalid action. Use BUY or SELL.")
