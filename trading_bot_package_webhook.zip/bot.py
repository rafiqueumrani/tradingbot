import os
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from binance.client import Client
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

API_KEY = os.getenv("BINANCE_API_KEY")
API_SECRET = os.getenv("BINANCE_API_SECRET")
USE_TESTNET = os.getenv("USE_TESTNET", "True") == "True"
WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET")

client = Client(API_KEY, API_SECRET, testnet=USE_TESTNET)

@app.get("/")
async def root():
    return {"message": "Trading Bot is running!"}

def buy(symbol, quantity):
    try:
        order = client.create_test_order(
            symbol=symbol,
            side="BUY",
            type="MARKET",
            quantity=quantity
        )
        return order
    except Exception as e:
        return {"error": str(e)}

def sell(symbol, quantity):
    try:
        order = client.create_test_order(
            symbol=symbol,
            side="SELL",
            type="MARKET",
            quantity=quantity
        )
        return order
    except Exception as e:
        return {"error": str(e)}

@app.post("/webhook")
async def webhook(request: Request):
    data = await request.json()
    secret = data.get("secret")

    if secret != WEBHOOK_SECRET:
        return JSONResponse(content={"error": "Invalid secret"}, status_code=403)

    action = data.get("action")
    symbol = data.get("symbol", "BTCUSDT")
    quantity = float(data.get("quantity", 0.001))

    if action == "BUY":
        result = buy(symbol, quantity)
        return {"message": "Buy order placed", "details": result}
    elif action == "SELL":
        result = sell(symbol, quantity)
        return {"message": "Sell order placed", "details": result}
    else:
        return {"error": "Invalid action"}
